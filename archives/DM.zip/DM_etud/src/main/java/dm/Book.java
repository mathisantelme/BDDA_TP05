package dm;

/**
 * Domain class representing a book
 */
public class Book {
    /* TO COMPLETE */
}
